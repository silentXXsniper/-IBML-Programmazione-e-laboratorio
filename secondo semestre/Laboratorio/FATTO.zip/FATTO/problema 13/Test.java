   import queens.*;
   javac -classpath "queens.jar;." Test.java
   java  -classpath "queens.jar;." Test
   ChessboardView view = new ChessboardView( n );
   view.setQueens(s);

public class Test
{   
     
}
