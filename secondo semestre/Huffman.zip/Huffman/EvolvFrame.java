
public class EvolvFrame{
    
    
    public int state;
    public Node lft, rgt;
    
    public EvolvFrame(){
        
        state = 0;
    }
    
}
