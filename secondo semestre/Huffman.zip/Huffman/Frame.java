public class Frame{  //
    
    public final String path;
    public final Node node;
    
    public Frame(String p, Node n){
        
        path = p;
        node = n;
    }
    
}//class Frame
